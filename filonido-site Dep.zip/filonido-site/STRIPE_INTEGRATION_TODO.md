# Stripe integration: cosa resta da fare

## Values to Replace

The following values are placeholders and must be updated before going live.

**Files containing placeholders:**
- [functions/api/create-checkout-session.js](functions/api/create-checkout-session.js)
- [index.html](index.html)
- [privacy.html](privacy.html), [termini.html](termini.html), [resi.html](resi.html)

| Field | Current Value | What to Set |
|-------|--------------|-------------|
| mode | payment | "payment" for one-time charges (already correct). |
| line_items[].price | price_... | Your Stripe Price ID for **€8.99** (https://dashboard.stripe.com/prices). Quantity (1 to 3) is set by the customer. |
| STRIPE_PUBLISHABLE_KEY (index.html) | pk_test_... | Your publishable key from https://dashboard.stripe.com/test/apikeys |
| PIXEL_ID (assets/consent.js) | "" | Your Meta Pixel ID. The pixel loads only after the visitor accepts cookies. |

## Configured Parameters

These parameters were configured in Checkout Studio and are already set correctly.

**Files containing these parameters:**
- [functions/api/create-checkout-session.js](functions/api/create-checkout-session.js)

| Parameter | Value |
|-----------|-------|
| ui_mode | form |
| billing_address_collection | required |
| phone_number_collection | enabled: false |
| automatic_tax | enabled: false |
| submit_type | auto |
| shipping_address_collection | allowed_countries: IT |
| name_collection | individual enabled |
| integration_identifier | custom_embedded_web_0002 |

`payment_method_collection` is omitted on purpose (only for subscriptions). `return_url` sends customers to `grazie.html` after payment. The chosen color is saved as `metadata.colore` on the Checkout Session and the payment, so you see it in the Stripe Dashboard.

## Setup and next steps

**Hosting (free): Cloudflare Pages**
1. Upload this folder to a Git repo (or use Direct Upload) and create a Cloudflare Pages project. No build command is needed; the `functions/` folder deploys with the site.
2. In Pages > Settings > Variables and Secrets add `STRIPE_SECRET_KEY` (sk_test_... first) and `DOMAIN` (e.g. https://yourdomain.it, no trailing slash).
3. Pages > Custom domains: connect your domain.
4. Put your publishable key in `index.html`.

**Project structure**
- `index.html`: landing page, color and quantity selector (max 3), embedded Stripe form
- `grazie.html`: post-payment page
- `privacy.html`, `termini.html`, `resi.html`: legal pages (Privacy and Cookie, Terms, Returns)
- `functions/api/create-checkout-session.js`: server endpoint (Stripe API 2026-03-25.dahlia); validates color and limits quantity to 3
- `assets/`: logo, photos, video, `consent.js` (cookie banner), `legal.css`

**How it works:** the customer picks color and quantity → clicks "Ordina ora" → the page calls `/api/create-checkout-session` → Stripe form appears in the page → after payment the customer lands on `grazie.html`. Changing color or quantity reloads the form.

**Testing:** use test keys. Card 4242 4242 4242 4242, any future date, any CVC, Italian address.

**Before going live**
- The site shows no P.IVA and the pages offer a 30-day return. Check with your accountant that this is allowed for your business.
- Have the legal pages read by a lawyer or accountant. They are standard Italian e-commerce texts, not legal advice. Two business choices to confirm: return shipping is paid by the customer (legal default), and shipping is Italy only.
- Add shipping cost in Stripe if you charge for delivery; the legal pages say costs are shown before payment.
- Real reviews only: add them to the `REVIEWS` list in `index.html`.
- Fulfillment: set a webhook for `checkout.session.completed`, or check orders in the Stripe Dashboard.

Resources: https://support.stripe.com and https://docs.stripe.com/mcp
